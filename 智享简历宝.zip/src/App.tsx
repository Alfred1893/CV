import React from 'react';
import PersonalWebsite from './index';

const App: React.FC = () => {
  return <PersonalWebsite />;
};

export default App;
