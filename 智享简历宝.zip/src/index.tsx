import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import PersonalIntro from './components/PersonalIntro';
import PastExperience from './components/PastExperience';
import BusinessAnalysis from './components/BusinessAnalysis';
import InterestsOthers from './components/InterestsOthers';
import Navigation from './components/Navigation';

const PersonalWebsite: React.FC = () => {
  const [activeSection, setActiveSection] = useState('intro');

  // 监听滚动事件，自动更新导航状态
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['intro', 'experience', 'product-skills', 'digital-intelligence', 'business-analysis', 'interests'];
      
      // 获取当前滚动位置
      const scrollPosition = window.scrollY + 200; // 添加偏移量，提前触发切换
      
      // 找到当前可视区域的section
      for (let i = sections.length - 1; i >= 0; i--) {
        const element = document.getElementById(sections[i]);
        if (element && element.offsetTop <= scrollPosition) {
          setActiveSection(sections[i]);
          break;
        }
      }
    };

    // 添加滚动监听
    window.addEventListener('scroll', handleScroll);
    
    // 初始化时也执行一次
    handleScroll();

    // 清理函数
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Navigation activeSection={activeSection} setActiveSection={setActiveSection} />
      
      <main className="ml-64">
        <section id="intro" className="min-h-screen">
          <PersonalIntro />
        </section>
        
        <section id="experience" className="min-h-screen py-20">
          <PastExperience />
        </section>
        
        <section id="product-skills" className="min-h-screen py-20">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-8">
              <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
                产品能力展示
              </h2>
              <p className="text-xl text-gray-600">
                完整的产品能力说明文档
              </p>
            </div>
            
            <div className="bg-white rounded-3xl shadow-xl border border-gray-200 overflow-hidden">
              <iframe 
                src="https://o89xiyyt68.feishu.cn/docx/RZ6Wd9MhHoj78cxH2gpclG4ZnXL?from=from_copylink"
                className="w-full"
                style={{ height: 'calc(100vh - 300px)', minHeight: '600px' }}
                frameBorder="0"
                allowFullScreen
                title="产品能力展示文档"
              />
            </div>
          </div>
        </section>
        
        <section id="digital-intelligence" className="min-h-screen py-20">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-8">
              <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
                数智化转型认知
              </h2>
              <p className="text-xl text-gray-600">
                企业AI Ready转型与业务协同化架构的深度思考
              </p>
            </div>
            
            <div className="bg-white rounded-3xl shadow-xl border border-gray-200 overflow-hidden">
              <iframe 
                src="https://o89xiyyt68.feishu.cn/docx/I0QfdBKZtomWwBx4NxNcNLPQnse?from=from_copylink"
                className="w-full"
                style={{ height: 'calc(100vh - 300px)', minHeight: '600px' }}
                frameBorder="0"
                allowFullScreen
                title="数智化转型认知文档"
              />
            </div>
          </div>
        </section>
        
        <section id="business-analysis" className="min-h-screen py-20">
          <BusinessAnalysis />
        </section>
        
        <section id="interests" className="min-h-screen py-20">
          <InterestsOthers />
        </section>
      </main>
    </div>
  );
};

export default PersonalWebsite;