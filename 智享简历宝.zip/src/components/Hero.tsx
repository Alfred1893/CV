/**
 * 首页英雄区域组件
 * 展示个人核心信息和职业亮点
 */
import React from 'react';
import { MapPin, Calendar, Users, TrendingUp } from 'lucide-react';

const Hero: React.FC = () => {
  const highlights = [
    { icon: Calendar, label: '总工作年限', value: '10年' },
    { icon: Users, label: '团队管理经验', value: '3年' },
    { icon: TrendingUp, label: '数字化项目', value: '20+' },
    { icon: MapPin, label: '工作地点', value: '上海' },
  ];

  return (
    <div className="flex items-center justify-center min-h-screen pt-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* 左侧个人信息 */}
          <div className="space-y-8">
            <div className="space-y-6">
              <div className="space-y-2">
                <h2 className="text-2xl font-semibold text-gray-700">
                  数字化转型咨询经理 | 产品经理
                </h2>
                <p className="text-lg text-gray-600">
                  字节跳动 飞书事业部
                </p>
              </div>
              
              <p className="text-lg text-gray-600 leading-relaxed">
                专注于数字化转型、产品管理和企业级解决方案设计，具有丰富的B端产品经验和跨行业项目管理能力。
                擅长从0到1的产品全生命周期管理，在MarTech、SaaS、低代码平台等领域有深度实践。
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              {highlights.map((item, index) => {
                const Icon = item.icon;
                return (
                  <div
                    key={index}
                    className="bg-white/70 backdrop-blur-sm p-4 rounded-2xl shadow-lg border border-white/20 hover:shadow-xl transition-all duration-300"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-2 rounded-lg">
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">{item.label}</p>
                        <p className="text-lg font-bold text-gray-800">{item.value}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          
          {/* 右侧个人头像区域 */}
          <div className="flex justify-center">
            <div className="relative">
              <div className="w-80 h-80 bg-gradient-to-br from-blue-400 via-purple-500 to-indigo-600 rounded-full shadow-2xl flex items-center justify-center">
                <div className="w-72 h-72 bg-white/10 backdrop-blur-sm rounded-full overflow-hidden flex items-center justify-center">
                  <img 
                    src="https://cdn-tos-cn.bytedance.net/obj/aipa-tos/9eb57b61-726a-41a5-ba60-bd3a195936b1-我的照片.png"
                    alt="李博个人照片"
                    className="w-full h-full object-cover rounded-full"
                  />
                </div>
              </div>
              
              {/* 装饰元素 */}
              <div className="absolute -top-4 -right-4 w-20 h-20 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full opacity-80 animate-pulse"></div>
              <div className="absolute -bottom-8 -left-8 w-16 h-16 bg-gradient-to-r from-green-400 to-blue-500 rounded-full opacity-60 animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;