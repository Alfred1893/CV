/**
 * 核心项目展示组件
 * 根据PRD更新，突出专利成果和产品创新
 */
import React from 'react';
import { ExternalLink, TrendingUp, Users, Award, Patent, Cpu } from 'lucide-react';

const Projects: React.FC = () => {
  const projects = [
    {
      title: '基于iPaaS/aPaaS的低零代码平台',
      company: '字节跳动',
      period: '2021.10 - 至今',
      description: '负责基于PaaS的插件产品组，独立从0到1规划整套方案，主导从设计到落地全流程实施，为公司沉淀10+项发明专利',
      highlights: [
        '获得10+项软件发明专利',
        '应用客户数500+',
        '服务行业头部企业20+',
        'aPaaS/iPaaS/AI Agent解决方案'
      ],
      tags: ['iPaaS', 'aPaaS', 'AI Agent', '低代码', '发明专利'],
      metrics: [
        { label: '发明专利', value: '10+', icon: Patent },
        { label: '应用客户', value: '500+', icon: Users },
        { label: '头部企业', value: '20+', icon: TrendingUp }
      ],
      patent: true,
      patentDescription: '主导插件产品组设计，在企业系统集成、流程自动化、AI应用等领域获得多项发明专利'
    },
    {
      title: '基于NLP的品牌数智化运营模块',
      company: '字节跳动',
      period: '2022.01 - 至今',
      description: '参与MarTech条线产品矩阵前期战略层设计，独立负责基于NLP的品牌数智化运营模块从0到1的产品全生命周期管理',
      highlights: [
        '服务客户500+',
        'MarTech产品矩阵设计',
        'NLP技术产品化应用',
        '品牌营销智能化'
      ],
      tags: ['MarTech', 'NLP', '品牌营销', '数智化', 'SaaS'],
      metrics: [
        { label: '服务客户', value: '500+', icon: Users },
        { label: 'NLP模型', value: '3+', icon: Cpu },
        { label: '营销场景', value: '10+', icon: TrendingUp }
      ]
    },
    {
      title: '企业审批集成与统一待办治理方案',
      company: '字节跳动',
      period: '2021.12 - 2023.06',
      description: '负责标杆客户的企业审批集成与统一待办数字化治理方案、BPM解决方案设计，服务行业头部（战略大客户）企业20+',
      highlights: [
        '服务头部企业20+',
        'BPM解决方案设计',
        '跨系统集成架构',
        '数字化治理方案'
      ],
      tags: ['BPM', '系统集成', '数字化治理', '企业级'],
      metrics: [
        { label: '头部客户', value: '20+', icon: Users },
        { label: '集成系统', value: '50+', icon: TrendingUp },
        { label: '流程优化', value: '100+', icon: Award }
      ]
    },
    {
      title: '新一代SRM产品化解决方案',
      company: '字节跳动',
      period: '2022.06 - 2023.12',
      description: '带领团队从0到1探索规划（协同+智能）新一代SRM产品化解决方案，主导方案在行业头部大客户从设计到落地',
      highlights: [
        '协同+智能化设计理念',
        '产品化解决方案',
        '头部客户落地验证',
        '供应商生态协同'
      ],
      tags: ['SRM', '供应链管理', '产品化', '智能协同'],
      metrics: [
        { label: '供应商数', value: '1000+', icon: Users },
        { label: '采购效率提升', value: '30%', icon: TrendingUp },
        { label: '成本节约', value: '15%', icon: Award }
      ]
    },
    {
      title: '财务共享数字化转型项目',
      company: '汉得信息',
      period: '2018.07 - 2019.07',
      description: '某合资保险公司数字化费用控制与财务管理咨询与实施项目，17家省级分公司业务流程再造（BPR），独立负责银企直联功能模块',
      highlights: [
        '17家分公司BPR改造',
        '财务自动化流程设计',
        '银企直联功能模块',
        '数字化转型咨询'
      ],
      tags: ['财务管理', 'BPR', 'FSSC', '数字化转型'],
      metrics: [
        { label: '覆盖分公司', value: '17家', icon: Users },
        { label: '效率提升', value: '25%', icon: TrendingUp },
        { label: 'PRD文档', value: '2万字', icon: Award }
      ]
    },
    {
      title: '航天器质量控制数字化转型',
      company: '中国人民解放军空军',
      period: '2015.06 - 2018.06',
      description: '参与涉及30余专家8个关键组织部门的重大跨职能小组研究，颠覆性地进行高精尖航天器质量控制工作的数字化转型',
      highlights: [
        '工作效率提升75%',
        '30余专家参与',
        '8个关键组织协同',
        '颠覆性数字化改造'
      ],
      tags: ['质量控制', '航天器', 'CFT', '数字化转型'],
      metrics: [
        { label: '效率提升', value: '75%', icon: TrendingUp },
        { label: '参与专家', value: '30+', icon: Users },
        { label: '协同部门', value: '8个', icon: Award }
      ]
    }
  ];

  const patentAchievements = [
    {
      category: '企业系统集成',
      count: '3项',
      description: '基于iPaaS平台的企业系统集成方法与装置'
    },
    {
      category: '流程自动化',
      count: '4项', 
      description: '智能审批流程引擎设计与优化方法'
    },
    {
      category: 'AI应用',
      count: '3项',
      description: '基于NLP的智能营销决策支持系统'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
          核心项目与专利成果
        </h2>
        <p className="text-xl text-gray-600">
          产品创新实践与知识产权积累
        </p>
      </div>

      {/* 专利成果概览 */}
      <div className="mb-16">
        <h3 className="text-2xl font-bold text-gray-800 mb-8 flex items-center space-x-3">
          <Patent className="w-6 h-6 text-yellow-600" />
          <span>发明专利成果（10+项）</span>
        </h3>
        <div className="grid md:grid-cols-3 gap-6">
          {patentAchievements.map((patent, index) => (
            <div key={index} className="bg-gradient-to-br from-yellow-50 to-orange-50 p-6 rounded-2xl border border-yellow-200 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <h4 className="text-lg font-bold text-gray-800">{patent.category}</h4>
                <span className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                  {patent.count}
                </span>
              </div>
              <p className="text-gray-600 text-sm">{patent.description}</p>
            </div>
          ))}
        </div>
      </div>
      
      {/* 项目详情 */}
      <div className="grid gap-8">
        {projects.map((project, index) => (
          <div key={index} className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl border border-white/20 overflow-hidden hover:shadow-2xl transition-all duration-300">
            <div className="p-8">
              <div className="flex flex-col lg:flex-row lg:items-start lg:space-x-8">
                {/* 项目信息 */}
                <div className="flex-1 space-y-6">
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-2xl font-bold text-gray-800">{project.title}</h3>
                      <div className="flex items-center space-x-2">
                        {project.patent && (
                          <div className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center space-x-1">
                            <Patent className="w-3 h-3" />
                            <span>专利项目</span>
                          </div>
                        )}
                        <ExternalLink className="w-5 h-5 text-gray-400 hover:text-blue-600 cursor-pointer transition-colors" />
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-4 mb-4">
                      <span className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-4 py-2 rounded-full text-sm font-medium">
                        {project.company}
                      </span>
                      <span className="text-gray-500 text-sm">{project.period}</span>
                    </div>
                    <p className="text-gray-600 leading-relaxed mb-6">{project.description}</p>
                    
                    {project.patent && project.patentDescription && (
                      <div className="bg-gradient-to-r from-yellow-50 to-orange-50 p-4 rounded-xl border border-yellow-200 mb-6">
                        <div className="flex items-start space-x-2">
                          <Patent className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                          <div>
                            <h5 className="font-semibold text-yellow-800 mb-1">专利成果</h5>
                            <p className="text-sm text-yellow-700">{project.patentDescription}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  {/* 项目亮点 */}
                  <div>
                    <h4 className="text-lg font-semibold text-gray-800 mb-3">项目亮点</h4>
                    <div className="grid md:grid-cols-2 gap-3">
                      {project.highlights.map((highlight, highlightIndex) => (
                        <div key={highlightIndex} className="flex items-start space-x-3">
                          <div className="w-2 h-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mt-2 flex-shrink-0"></div>
                          <span className="text-gray-600">{highlight}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* 技术标签 */}
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag, tagIndex) => (
                      <span key={tagIndex} className="bg-gradient-to-r from-blue-50 to-purple-50 text-blue-700 px-3 py-1 rounded-full text-sm font-medium border border-blue-200">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                
                {/* 项目指标 */}
                <div className="lg:w-80 mt-6 lg:mt-0">
                  <div className="bg-gradient-to-br from-gray-50 to-blue-50 p-6 rounded-2xl">
                    <h4 className="text-lg font-semibold text-gray-800 mb-4">项目成果</h4>
                    <div className="space-y-4">
                      {project.metrics.map((metric, metricIndex) => {
                        const Icon = metric.icon;
                        return (
                          <div key={metricIndex} className="flex items-center space-x-3">
                            <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-2 rounded-lg">
                              <Icon className="w-4 h-4 text-white" />
                            </div>
                            <div>
                              <p className="text-sm text-gray-600">{metric.label}</p>
                              <p className="text-xl font-bold text-gray-800">{metric.value}</p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Projects;