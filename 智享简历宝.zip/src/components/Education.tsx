/**
 * 教育背景组件
 * 展示学术经历和相关课程
 */
import React from 'react';
import { GraduationCap, Award, BookOpen, Calendar } from 'lucide-react';

const Education: React.FC = () => {
  const educations = [
    {
      period: '2019 - 2020',
      school: '香港大学',
      schoolEn: 'THE UNIVERSITY OF HONGKONG',
      degree: '硕士',
      major: '工业工程及物流管理（财管与金融方向）',
      majorEn: 'Industrial Engineering and Logistics Management (Finance)',
      courses: [
        '金融工程',
        '投资与交易', 
        '工程经济学',
        '物联网',
        '运营风险管理',
        '组织管理与战略',
        '运筹学'
      ],
      highlight: '财管与金融方向',
      location: '香港'
    },
    {
      period: '2011 - 2015',
      school: '哈尔滨工业大学',
      schoolEn: 'HARBIN INSTITUTE OF TECHNOLOGY',
      degree: '学士',
      major: '机电工程',
      majorEn: 'Mechanical Engineering',
      achievement: '获人民奖学金',
      courses: [
        '机械设计',
        '控制工程',
        '工程力学',
        '材料科学',
        '制造工程',
        '自动化技术'
      ],
      highlight: '985工程重点大学',
      location: '哈尔滨'
    }
  ];

  const additionalExperiences = [
    {
      period: '2020.06 - 2020.09',
      company: '联合利华 UNILEVER',
      position: '品牌市场战略（实习）',
      type: 'internship',
      location: '上海，中国',
      description: '在某知名品牌Relaunch战略的初期阶段参与新品类Innovation Proposal，独立负责一个子品类',
      achievements: [
        '搭建问题分析框架、与Nielsen（尼尔森）、Kantar（凯度）以及公司内部CMI部门合作，完成数据驱动的市场分析、用户画像',
        '基于数据库的竞品分析，from insights to concepts, 符合品牌战略的产品6P模型确立',
        'Business case财务建模，项目ROI估算；通过AI test以及内部流程审计，达成Concept Pass'
      ]
    },
    {
      period: '2020.03 - 2020.05',
      company: '嘉实资本（私募股权基金）',
      position: '投资分析师（实习）',
      type: 'internship',
      location: '北京，中国',
      description: 'B/C轮融资项目（专注：产业数字化转型与物联网应用）投资前期研究',
      achievements: [
        '了解商业分析的基本逻辑、框架和方法，自主从包括wind数据库在内的多渠道收集数据，使用SQL/Excel进行数据清洗与分析',
        '多次参加路演。能提出一些有价值的问题，得到一些合理的结论，在尽调中发现一些问题',
        '进行基本的标的公司财务分析；完成行业研究，企业研究，使用tableau进行数据可视化，独立出具初步研究报告'
      ]
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
          教育背景
        </h2>
        <p className="text-xl text-gray-600">
          扎实的学术基础与持续的学习实践
        </p>
      </div>
      
      {/* 正式教育经历 */}
      <div className="space-y-8 mb-16">
        {educations.map((edu, index) => (
          <div key={index} className="bg-white/80 backdrop-blur-sm p-8 rounded-3xl shadow-xl border border-white/20 hover:shadow-2xl transition-all duration-300">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* 左侧：基本信息 */}
              <div className="lg:col-span-1 space-y-4">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-3 rounded-2xl">
                    <GraduationCap className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-800">{edu.degree}</h3>
                    <div className="flex items-center space-x-2 text-sm text-blue-600">
                      <Calendar className="w-4 h-4" />
                      <span>{edu.period}</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h4 className="text-lg font-bold text-gray-800">{edu.school}</h4>
                  <p className="text-sm text-gray-500 uppercase tracking-wider">{edu.schoolEn}</p>
                  <p className="text-gray-600">{edu.location}</p>
                </div>
                
                <div className="bg-gradient-to-r from-green-50 to-blue-50 p-3 rounded-2xl">
                  <p className="text-sm font-medium text-green-700">
                    {edu.highlight}
                  </p>
                </div>
                
                {edu.achievement && (
                  <div className="flex items-center space-x-2 bg-gradient-to-r from-yellow-50 to-orange-50 p-3 rounded-2xl">
                    <Award className="w-5 h-5 text-yellow-600" />
                    <span className="text-sm font-medium text-yellow-700">{edu.achievement}</span>
                  </div>
                )}
              </div>
              
              {/* 右侧：专业和课程 */}
              <div className="lg:col-span-2 space-y-6">
                <div>
                  <h4 className="text-lg font-bold text-gray-800 mb-2">{edu.major}</h4>
                  <p className="text-gray-500 text-sm uppercase tracking-wider">{edu.majorEn}</p>
                </div>
                
                <div>
                  <div className="flex items-center space-x-2 mb-4">
                    <BookOpen className="w-5 h-5 text-purple-600" />
                    <h5 className="font-semibold text-gray-800">主要课程</h5>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {edu.courses.map((course, courseIndex) => (
                      <div key={courseIndex} className="bg-gradient-to-r from-purple-50 to-blue-50 px-3 py-2 rounded-xl border border-purple-200">
                        <span className="text-sm font-medium text-purple-700">{course}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {/* 实习经历 */}
      <div className="bg-white/80 backdrop-blur-sm p-8 rounded-3xl shadow-xl border border-white/20">
        <h3 className="text-2xl font-bold text-gray-800 mb-8 flex items-center space-x-3">
          <Award className="w-6 h-6 text-orange-500" />
          <span>实习经历</span>
        </h3>
        
        <div className="space-y-6">
          {additionalExperiences.map((exp, index) => (
            <div key={index} className="border-l-4 border-gradient-to-b from-orange-500 to-red-500 pl-6">
              <div className="space-y-3">
                <div className="flex flex-wrap items-center gap-4">
                  <h4 className="text-lg font-bold text-gray-800">{exp.company}</h4>
                  <span className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {exp.position}
                  </span>
                  <span className="text-gray-500 text-sm">{exp.period}</span>
                  <span className="text-gray-500 text-sm">{exp.location}</span>
                </div>
                
                <p className="text-gray-600 leading-relaxed">{exp.description}</p>
                
                <div className="space-y-2">
                  {exp.achievements.map((achievement, achievementIndex) => (
                    <div key={achievementIndex} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-gradient-to-r from-orange-500 to-red-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-600 text-sm leading-relaxed">{achievement}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Education;
