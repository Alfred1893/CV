/**
 * 技能展示组件
 * 以可视化方式展示专业技能和工具掌握情况
 */
import React from 'react';
import { Code, Database, BarChart3, Palette, Globe, Award } from 'lucide-react';

const Skills: React.FC = () => {
  const skillCategories = [
    {
      title: '产品管理',
      icon: BarChart3,
      color: 'from-blue-500 to-blue-600',
      skills: [
        { name: 'B端产品设计', level: 95 },
        { name: '需求分析', level: 90 },
        { name: '原型设计', level: 85 },
        { name: 'PRD写作', level: 90 },
        { name: '用户研究', level: 80 }
      ]
    },
    {
      title: '数字化转型',
      icon: Code,
      color: 'from-purple-500 to-purple-600',
      skills: [
        { name: 'BPR业务流程再造', level: 90 },
        { name: 'IT咨询', level: 85 },
        { name: 'SaaS产品规划', level: 90 },
        { name: '企业架构设计', level: 80 },
        { name: '数字化策略', level: 85 }
      ]
    },
    {
      title: '技术工具',
      icon: Database,
      color: 'from-green-500 to-green-600',
      skills: [
        { name: 'SQL数据处理', level: 80 },
        { name: 'Tableau数据可视化', level: 75 },
        { name: 'Figma/Axure原型', level: 85 },
        { name: 'Office套件', level: 90 },
        { name: 'Visio流程图', level: 80 }
      ]
    },
    {
      title: '项目管理',
      icon: Award,
      color: 'from-orange-500 to-orange-600',
      skills: [
        { name: 'PMP项目管理', level: 95 },
        { name: '敏捷开发', level: 80 },
        { name: '团队管理', level: 85 },
        { name: '跨部门协作', level: 90 },
        { name: '风险管理', level: 80 }
      ]
    },
    {
      title: '业务分析',
      icon: Palette,
      color: 'from-pink-500 to-pink-600',
      skills: [
        { name: '商业分析', level: 85 },
        { name: '竞品分析', level: 80 },
        { name: '市场研究', level: 75 },
        { name: '财务建模', level: 70 },
        { name: '投资分析', level: 75 }
      ]
    },
    {
      title: '语言能力',
      icon: Globe,
      color: 'from-indigo-500 to-indigo-600',
      skills: [
        { name: '中文（母语）', level: 100 },
        { name: '英文（熟练）', level: 85 },
        { name: '商务英语', level: 80 },
        { name: '技术文档', level: 85 },
        { name: '演讲表达', level: 90 }
      ]
    }
  ];

  const certifications = [
    {
      name: 'PMP项目管理专家认证',
      issuer: 'PMI',
      year: '2018',
      icon: Award
    },
    {
      name: '软件发明专利',
      issuer: '国家知识产权局',
      year: '2021-2023',
      count: '10+',
      icon: Code
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
          专业技能
        </h2>
        <p className="text-xl text-gray-600">
          多年积累的专业技能与工具掌握情况
        </p>
      </div>
      
      {/* 技能矩阵 */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
        {skillCategories.map((category, index) => {
          const Icon = category.icon;
          return (
            <div key={index} className="bg-white/80 backdrop-blur-sm p-6 rounded-3xl shadow-xl border border-white/20 hover:shadow-2xl transition-all duration-300">
              <div className="flex items-center space-x-3 mb-6">
                <div className={`bg-gradient-to-r ${category.color} p-3 rounded-2xl`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-800">{category.title}</h3>
              </div>
              
              <div className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700 font-medium">{skill.name}</span>
                      <span className="text-sm text-gray-500">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`bg-gradient-to-r ${category.color} h-2 rounded-full transition-all duration-1000 ease-out`}
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      
      {/* 认证证书 */}
      <div className="bg-white/80 backdrop-blur-sm p-8 rounded-3xl shadow-xl border border-white/20">
        <h3 className="text-2xl font-bold text-gray-800 mb-6 flex items-center space-x-3">
          <Award className="w-6 h-6 text-yellow-500" />
          <span>专业认证</span>
        </h3>
        
        <div className="grid md:grid-cols-2 gap-6">
          {certifications.map((cert, index) => {
            const Icon = cert.icon;
            return (
              <div key={index} className="flex items-center space-x-4 p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-2xl border border-yellow-200">
                <div className="bg-gradient-to-r from-yellow-500 to-orange-500 p-3 rounded-xl">
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="font-bold text-gray-800">{cert.name}</h4>
                  <p className="text-gray-600">{cert.issuer} • {cert.year}</p>
                  {cert.count && <p className="text-sm text-orange-600 font-medium">{cert.count}</p>}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Skills;