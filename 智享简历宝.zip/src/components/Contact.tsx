/**
 * 联系方式组件
 * 提供多种联系方式和个人兴趣展示
 */
import React from 'react';
import { Phone, Mail, MapPin, Download, Heart, Camera, Plane, Coffee } from 'lucide-react';

const Contact: React.FC = () => {
  const contactInfo = [
    {
      icon: Phone,
      label: '手机号码',
      value: '+86 18645043893',
      href: 'tel:+8618645043893'
    },
    {
      icon: Mail,
      label: '邮箱地址',
      value: 'alfred18931994@outlook.com',
      href: 'mailto:alfred18931994@outlook.com'
    },
    {
      icon: MapPin,
      label: '工作地点',
      value: '上海，中国',
      href: null
    }
  ];

  const interests = [
    { name: '独立背包旅行', detail: '>100城市', icon: Plane },
    { name: '高尔夫', detail: '业余爱好', icon: Coffee },
    { name: '拳击', detail: '健身运动', icon: Heart },
    { name: '射箭', detail: '精准运动', icon: Heart },
    { name: '帆船', detail: 'DC22', icon: Plane },
    { name: '演讲', detail: '公众表达', icon: Coffee },
    { name: '文学与电影评论', detail: '艺术鉴赏', icon: Coffee },
    { name: '单一麦芽威士忌', detail: '品鉴收藏', icon: Coffee },
    { name: '摄影', detail: '生活记录', icon: Camera }
  ];

  const stats = [
    { label: '总工作年限', value: '10年' },
    { label: '团队管理经验', value: '3年' },
    { label: '团队规模', value: '6人' },
    { label: '数字化项目', value: '20+' },
    { label: '软件发明专利', value: '10+' }
  ];

  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
          联系方式
        </h2>
        <p className="text-xl text-gray-600">
          期待与您的合作机会
        </p>
      </div>
      
      <div className="grid lg:grid-cols-2 gap-12">
        {/* 左侧：联系信息和统计 */}
        <div className="space-y-8">
          {/* 联系方式 */}
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-3xl shadow-xl border border-white/20">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">联系信息</h3>
            <div className="space-y-4">
              {contactInfo.map((contact, index) => {
                const Icon = contact.icon;
                const content = (
                  <div className="flex items-center space-x-4 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl border border-blue-200 hover:shadow-md transition-all duration-300">
                    <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-3 rounded-xl">
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">{contact.label}</p>
                      <p className="text-lg font-semibold text-gray-800">{contact.value}</p>
                    </div>
                  </div>
                );
                
                return contact.href ? (
                  <a key={index} href={contact.href} className="block">
                    {content}
                  </a>
                ) : (
                  <div key={index}>
                    {content}
                  </div>
                );
              })}
            </div>
          </div>
          
          {/* 职业统计 */}
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-3xl shadow-xl border border-white/20">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">职业概览</h3>
            <div className="grid grid-cols-2 gap-4">
              {stats.map((stat, index) => (
                <div key={index} className="text-center p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl">
                  <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
          
          {/* 简历下载 */}
          <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-8 rounded-3xl shadow-xl text-white">
            <div className="text-center space-y-4">
              <Download className="w-12 h-12 mx-auto" />
              <h3 className="text-xl font-bold">下载简历</h3>
              <p className="text-blue-100">获取完整的简历文档</p>
              <button className="bg-white text-blue-600 px-6 py-3 rounded-2xl font-semibold hover:bg-blue-50 transition-all duration-300 shadow-lg">
                下载 PDF 简历
              </button>
            </div>
          </div>
        </div>
        
        {/* 右侧：个人兴趣 */}
        <div className="bg-white/80 backdrop-blur-sm p-8 rounded-3xl shadow-xl border border-white/20">
          <h3 className="text-2xl font-bold text-gray-800 mb-6 flex items-center space-x-3">
            <Heart className="w-6 h-6 text-red-500" />
            <span>个人兴趣</span>
          </h3>
          
          <div className="space-y-4 mb-8">
            {interests.map((interest, index) => {
              const Icon = interest.icon;
              return (
                <div key={index} className="flex items-center space-x-4 p-4 bg-gradient-to-r from-pink-50 to-orange-50 rounded-2xl border border-pink-200 hover:shadow-md transition-all duration-300">
                  <div className="bg-gradient-to-r from-pink-500 to-orange-500 p-2 rounded-lg">
                    <Icon className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-gray-800">{interest.name}</p>
                    <p className="text-sm text-gray-600">{interest.detail}</p>
                  </div>
                </div>
              );
            })}
          </div>
          
          <div className="bg-gradient-to-r from-yellow-50 to-orange-50 p-6 rounded-2xl border border-yellow-200">
            <h4 className="font-bold text-gray-800 mb-3">生活态度</h4>
            <p className="text-gray-600 leading-relaxed">
              热爱生活，享受挑战。通过多样化的兴趣爱好保持工作与生活的平衡，
              在旅行中拓宽视野，在运动中锻炼意志，在艺术中陶冶情操。
              相信丰富的人生阅历能够为工作带来更多创新思维和解决问题的角度。
            </p>
          </div>
        </div>
      </div>
      
      {/* 底部 */}
      <div className="text-center mt-16 pb-8">
        <div className="bg-white/80 backdrop-blur-sm p-8 rounded-3xl shadow-xl border border-white/20">
          <h3 className="text-2xl font-bold text-gray-800 mb-4">期待合作</h3>
          <p className="text-gray-600 leading-relaxed max-w-2xl mx-auto">
            如果您正在寻找一位具有丰富经验的产品经理或数字化转型专家，
            我期待能够与您详细讨论如何为您的团队和项目创造价值。
            让我们一起探讨数字化转型的无限可能性。
          </p>
          <div className="flex justify-center space-x-4 mt-6">
            <a href="tel:+8618645043893" className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-6 py-3 rounded-2xl font-semibold hover:shadow-lg transition-all duration-300">
              立即联系
            </a>
            <a href="mailto:alfred18931994@outlook.com" className="bg-white text-gray-700 border-2 border-gray-300 px-6 py-3 rounded-2xl font-semibold hover:bg-gray-50 transition-all duration-300">
              发送邮件
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
