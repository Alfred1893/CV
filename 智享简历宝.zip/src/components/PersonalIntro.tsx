/**
 * 个人介绍组件
 * 根据PRD更新，突出产品管理和数字化转型专长，融入教育背景
 */
import React from 'react';
import { ArrowRight, Award, Target, Brain, GraduationCap, Calendar, MapPin } from 'lucide-react';

const PersonalIntro: React.FC = () => {
  const stats = [
    {
      label: '软件著作专利数量',
      value: '10+',
      subtitle: '基于低零代码平台的产品',
      icon: Award
    },
    {
      label: 'B端产品经验',
      value: '8年',
      subtitle: '从0到1产品全生命周期管理经验',
      icon: Target
    },
    {
      label: '数智化项目',
      value: '20+',
      subtitle: '服务行业头部企业数字化转型',
      icon: Brain
    }
  ];

  const coreCompetencies = [
    '企业应用架构设计',
    'B端产品',
    '协同数智化转型',
    'AI解决方案'
  ];

  const educations = [
    {
      period: '2019 - 2020',
      school: '香港大学',
      schoolEn: 'THE UNIVERSITY OF HONGKONG',
      degree: '硕士',
      major: '工业工程及物流管理（财管与金融方向）',
      courses: ['金融工程', '投资与交易', '工程经济学', '物联网', '运营风险管理', '组织管理与战略', '运筹学']
    },
    {
      period: '2011 - 2015',
      school: '哈尔滨工业大学',
      schoolEn: 'HARBIN INSTITUTE OF TECHNOLOGY',
      degree: '学士',
      major: '机电工程',
      achievement: '获人民奖学金'
    }
  ];

  return (
    <div className="flex items-center justify-center min-h-screen p-8">
      <div className="max-w-6xl mx-auto w-full">
        {/* 顶部标题区域 */}
        <div className="text-center mb-16">
          <p className="text-gray-500 text-xs uppercase tracking-wider mb-3">PRODUCT MANAGER & DIGITAL TRANSFORMATION EXPERT</p>
          <h1 className="text-6xl font-bold text-gray-900 mb-6">李博 Alfred Lee</h1>
          <p className="text-2xl text-gray-700 mb-6">B端产品 | 企业数智化转型</p>
        </div>

        {/* 主要内容区域 */}
        <div className="grid lg:grid-cols-2 gap-16 items-start mb-20">
          {/* 左侧：描述和能力 */}
          <div className="space-y-8 h-full flex flex-col">
            {/* 核心优势 */}
            <div className="flex-shrink-0">
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-xl h-full">
                <p className="text-lg text-gray-700 leading-relaxed">
                  <span className="font-semibold text-blue-700">核心优势：</span>
                  具备产品设计、咨询顾问、项目管理的复合能力，能够从战略层、范围层到结构层进行全链路产品设计。拥有深厚的企业信息架构设计能力和数字化转型实践经验。
                </p>
              </div>
            </div>

            {/* 核心专业能力部分 */}
            <div className="flex-1 flex flex-col justify-center">
              <h3 className="text-lg text-gray-900 font-semibold mb-6">核心专业能力</h3>
              <div className="grid grid-cols-2 gap-3">
                {coreCompetencies.map((competency, index) => (
                  <div
                    key={index}
                    className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-4 py-3 rounded-full font-semibold text-sm text-center shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                  >
                    {competency}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* 右侧：核心数据 */}
          <div className="h-full flex flex-col justify-between space-y-6">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="flex-1 flex items-center">
                  <div className="w-full bg-white/50 backdrop-blur-sm p-6 rounded-2xl border border-gray-100 hover:shadow-md transition-all duration-300">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-4">
                        <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-3 rounded-lg">
                          <Icon className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h3 className="text-lg text-gray-900 font-semibold mb-1">{stat.label}</h3>
                          <p className="text-sm text-gray-500">{stat.subtitle}</p>
                        </div>
                      </div>
                      <div className="text-4xl font-bold text-gray-900">{stat.value}</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 教育背景 */}
        <div className="mb-16">
          <div className="flex items-center justify-center mb-12">
            <div className="flex items-center space-x-3">
              <GraduationCap className="w-6 h-6 text-green-600" />
              <h3 className="text-2xl font-bold text-gray-900">教育背景</h3>
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {educations.map((edu, index) => (
              <div key={index} className="bg-gradient-to-br from-gray-50 to-blue-50 p-8 rounded-2xl border border-blue-100 hover:shadow-md transition-all duration-300">
                <div className="space-y-4">
                  <div className="flex items-center space-x-2 text-sm text-green-600 font-medium">
                    <Calendar className="w-4 h-4" />
                    <span>{edu.period}</span>
                  </div>
                  
                  <div>
                    <h4 className="text-xl font-bold text-gray-800">{edu.school}</h4>
                    <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">{edu.schoolEn}</p>
                    <p className="text-lg text-gray-700 font-medium mb-4">{edu.degree} • {edu.major}</p>
                    
                    {/* 主要课程 */}
                    {edu.courses && edu.courses.length > 0 && (
                      <div className="mb-4">
                        <p className="text-xs text-gray-500 mb-2">主要课程：</p>
                        <div className="flex flex-wrap gap-1">
                          {edu.courses.map((course, courseIndex) => (
                            <span key={courseIndex} className="text-xs bg-white/70 text-gray-600 px-2 py-1 rounded border">
                              {course}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {edu.achievement && (
                      <div className="flex items-center space-x-2 bg-gradient-to-r from-yellow-50 to-orange-50 p-3 rounded-lg">
                        <Award className="w-4 h-4 text-yellow-600" />
                        <span className="text-sm font-medium text-yellow-700">{edu.achievement}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PersonalIntro;