/**
 * 导航组件
 * 参考附件设计，采用深色侧边栏风格
 * 支持滚动时自动更新活跃状态
 */
import React from 'react';
import { User, Briefcase, Wrench, Brain, BarChart3, Heart, Hand, Mail, Phone } from 'lucide-react';

interface NavigationProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeSection, setActiveSection }) => {
  const navItems = [
    { id: 'intro', label: '个人介绍', icon: User },
    { id: 'experience', label: '过往经历', icon: Briefcase },
    { id: 'product-skills', label: '基础产品能力', icon: Wrench },
    { id: 'digital-intelligence', label: '数智化认知', icon: Brain },
    { id: 'business-analysis', label: '咨询/商业分析', icon: BarChart3 },
    { id: 'interests', label: '兴趣爱好/其他', icon: Heart }
  ];

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      // 使用平滑滚动，并考虑导航栏高度
      const offsetTop = element.offsetTop - 20; // 添加一点顶部间距
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
    }
  };

  return (
    <nav className="fixed left-0 top-0 h-full w-64 bg-gray-900 z-50 flex flex-col">
      <div className="p-6 flex-1">
        {/* 问候语 */}
        <div className="mb-8">
          <div className="flex items-center space-x-2 mb-4">
            <Hand className="w-6 h-6 text-yellow-400" />
            <span className="text-white text-lg font-medium">Say, Hello!!!</span>
          </div>
        </div>

        {/* 导航菜单 */}
        <div className="space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`group flex items-center space-x-3 w-full p-3 rounded-lg transition-all duration-300 text-left ${
                  isActive
                    ? 'bg-white text-gray-900 shadow-lg scale-105'
                    : 'text-gray-300 hover:bg-gray-800 hover:text-white transform hover:scale-102'
                }`}
              >
                <Icon className={`w-5 h-5 transition-all duration-300 ${
                  isActive ? 'text-blue-600' : 'group-hover:text-blue-400'
                }`} />
                <span className="text-sm font-medium">{item.label}</span>
                {isActive && (
                  <div className="ml-auto w-2 h-2 bg-blue-600 rounded-full animate-pulse" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 个人信息区域 - 移动到底部 */}
      <div className="p-6 border-t border-gray-800">
        <div className="flex items-center space-x-4 mb-4">
          <div className="w-12 h-12 rounded-full overflow-hidden ring-2 ring-gray-700">
            <img 
              src="https://cdn-tos-cn.bytedance.net/obj/aipa-tos/9eb57b61-726a-41a5-ba60-bd3a195936b1-我的照片.png"
              alt="李博"
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h3 className="text-white font-medium">李博 (Alfred Lee)</h3>
            <p className="text-gray-400 text-xs">产品经理 | 数智化专家</p>
          </div>
        </div>
        
        {/* 联系方式 */}
        <div className="space-y-2">
          <a 
            href="mailto:alfred18931994@outlook.com"
            className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors text-sm group"
          >
            <Mail className="w-4 h-4 flex-shrink-0 group-hover:text-blue-400 transition-colors" strokeWidth={1.5} />
            <span>alfred18931994@outlook.com</span>
          </a>
          <a 
            href="tel:+8618645043893"
            className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors text-sm group"
          >
            <Phone className="w-4 h-4 flex-shrink-0 group-hover:text-blue-400 transition-colors" strokeWidth={1.5} />
            <span>+86 18645043893</span>
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;