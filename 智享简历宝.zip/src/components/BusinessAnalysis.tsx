/**
 * 商业分析组件
 * 展示商业分析实践经验
 */
import React from 'react';
import { Calendar, MapPin, Award } from 'lucide-react';

const BusinessAnalysis: React.FC = () => {
  const internshipAnalysis = [
    {
      period: '2020.06 - 2020.09',
      company: '联合利华 UNILEVER',
      position: '品牌市场战略（实习）',
      location: '上海，中国',
      analysisCapabilities: [
        {
          area: '品牌价值分析',
          description: '参与品牌Relaunch项目，进行品牌价值主张重新设计',
          tools: '消费者洞察、竞品分析、6P营销模型'
        },
        {
          area: '市场研究',
          description: '与Nielsen、Kantar合作完成用户画像构建与市场分析',
          tools: 'SPSS数据分析、消费者调研、市场细分'
        },
        {
          area: '商业模式创新',
          description: '制定Innovation Proposal，包含财务建模与ROI分析',
          tools: '财务建模、风险评估、投资回报分析'
        }
      ]
    },
    {
      period: '2020.03 - 2020.05',
      company: '嘉实资本（私募股权基金）',
      position: '投资分析师（实习）',
      location: '北京，中国',
      analysisCapabilities: [
        {
          area: '投资前期研究',
          description: '负责B/C轮融资项目的行业研究与企业深度分析',
          tools: 'DCF建模、市场倍数法、敏感性分析'
        },
        {
          area: '财务分析',
          description: '基于Wind数据库进行财务建模与投资标的估值分析',
          tools: 'Wind数据库、三大报表分析、现金流分析'
        },
        {
          area: '行业分析',
          description: '进行行业发展趋势分析，识别投资机会与风险',
          tools: '行业研究框架、竞争格局分析、PEST分析'
        }
      ]
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
          咨询/商业分析
        </h2>
        <p className="text-xl text-gray-600">
          咨询思维与商业分析能力展示
        </p>
      </div>

      {/* 咨询分析文档展示 */}
      <div className="mb-16">
        <div className="bg-white rounded-3xl shadow-xl border border-gray-200 overflow-hidden">
          <iframe 
            src="https://o89xiyyt68.feishu.cn/docx/CLD2d82dgoWg5PxwGoFcYYg4n6R?from=from_copylink"
            className="w-full"
            style={{ height: 'calc(100vh - 300px)', minHeight: '600px' }}
            frameBorder="0"
            allowFullScreen
            title="咨询与商业分析文档"
          />
        </div>
      </div>

      {/* 商业分析实践 */}
      <div>
        <h3 className="text-2xl font-bold text-gray-800 mb-8 flex items-center space-x-3">
          <Award className="w-6 h-6 text-orange-600" />
          <span>商业分析实践</span>
        </h3>
        
        <div className="space-y-8">
          {internshipAnalysis.map((internship, index) => (
            <div key={index} className="bg-white/80 backdrop-blur-sm p-8 rounded-3xl shadow-xl border border-white/20 hover:shadow-2xl transition-all duration-300">
              <div className="space-y-6">
                <div className="border-l-4 border-orange-500 pl-6">
                  <div className="flex items-center space-x-2 text-sm text-orange-600 font-medium mb-2">
                    <Calendar className="w-4 h-4" />
                    <span>{internship.period}</span>
                  </div>
                  
                  <h4 className="text-xl font-bold text-gray-800 mb-1">{internship.company}</h4>
                  <p className="text-lg font-semibold text-gray-700 mb-2">{internship.position}</p>
                  <div className="flex items-center space-x-2 text-sm text-gray-500">
                    <MapPin className="w-4 h-4" />
                    <span>{internship.location}</span>
                  </div>
                </div>
                
                <div className="grid md:grid-cols-3 gap-6">
                  {internship.analysisCapabilities.map((capability, capIndex) => (
                    <div key={capIndex} className="bg-gradient-to-br from-orange-50 to-red-50 p-6 rounded-2xl border border-orange-200">
                      <div className="space-y-3">
                        <h5 className="font-bold text-orange-800">{capability.area}</h5>
                        <p className="text-sm text-gray-700 leading-relaxed">{capability.description}</p>
                        <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-2 rounded-lg">
                          <p className="text-xs"><span className="font-semibold">工具方法：</span>{capability.tools}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BusinessAnalysis;