/**
 * 过往经历组件
 * 专注展示工作经历
 */
import React from 'react';
import { Calendar, MapPin, Building, Briefcase } from 'lucide-react';

const PastExperience: React.FC = () => {
  const workExperiences = [
    {
      period: '2021.10 - 至今',
      company: '字节跳动 BYTEDANCE',
      department: '飞书事业部',
      position: '数智化转型咨询经理',
      location: '上海，中国',
      type: 'AI+ 低零代码平台产品 - aPaaS/iPaaS/AI Agent | 解决方案架构师',
      achievements: [
        '负责基于PaaS的插件产品组：独立从0到1规划整套方案，主导从设计到落地，应用客户数500+；为字节跳动沉淀10+国家发明专利',
        '业务流程管理数字化：负责标杆客户的企业审批集成与统一待办数字化治理方案、BPM解决方案设计，服务行业头部（战略大客户）企业20+',
        '采购管理业务领域协同化改造：带领团队从0到1探索规划（协同+智能）新一代SRM产品化解决方案，主导方案在行业头部大客户从设计到落地',
        '全程参与SaaS企业咨询中台部门建设与组织设计：作为Acting Leader，独立探索基于NCLC（+AI）技术路线的业务场景咨询与实施路径方法论'
      ]
    },
    {
      period: '2021.01 - 2021.10',
      company: '顺丰集团 SF EXPRESS',
      department: '科技产品处',
      position: '产品经理 / 战略与流程优化PMO',
      location: '上海，中国',
      type: '集团SaaS商业产品战略运营 | 内部管理咨询顾问 / 战略与流程优化PMO',
      achievements: [
        '作为各产品/项目线的战略伙伴执行团队与相关方管理联动销售、产品、项目、财务、法务等团队，不断优化系统、制度、标准和流程',
        '从0到1组建运营部，进行战略规划与人才建设，围绕岗位/专业主题建立各职级知识地图，根据人员不同特质采取不同的专业人才培养计划',
        '从0到1进行CSM数据运营体系搭建、业务流程设计（跨部门合作机制，包含基于OKR的目标与绩效管理方法设计等）',
        '对各行业展开深度分析，发现行业机会点与风险点，参与行业巨头标杆客户的C-Level交流，支持COO做出商业化关键决策'
      ]
    },
    {
      period: '2018.07 - 2019.07',
      company: '汉得信息 HAND ENTERPRISE SOLUTIONS',
      position: 'B端产品经理 / 咨询顾问',
      location: '上海，中国',
      type: '数字化转型（财务管理）项目 | 数字化解决方案咨询顾问',
      achievements: [
        '了解财务共享（FSSC）基本思想，熟悉企业内部费用控制（财务自动化）流程，数字化转型方案和行业最佳实践',
        '针对企业支付/资金业务设计数字化转型方案并组织实施；独立负责银企直联功能模块的产品从设计到实施落地全流程',
        '针对企业矩阵式管理与委派制管理相杂揉的实际，与总部管理层及17家省级分公司直接对接针对其中审批流程进行业务流程再造（BPR）',
        '通过过往项目复盘、案例包装、行业研报，独立负责SaaS产品/项目方案推广和售前物料库从0到1建立'
      ]
    },
    {
      period: '2015.06 - 2018.06',
      company: '中国人民解放军空军',
      department: '装备部门',
      position: 'B端产品经理 / 项目管理（PMO）',
      location: '中国',
      type: '数字化转型（装备质量控制）项目 | 产品经理',
      achievements: [
        '参与涉及30余专家8个关键组织/部门的重大跨职能小组（CFT）研究',
        '组织/参与超过100小时（净会议时间）多方会议，具有跨部门合作能力和资源整合能力',
        '参与战略层、范围层、结构层（信息架构）设计，颠覆性地进行高精尖航天器质量控制工作的数字化转型，使对象工作效率提升75%',
        '负责团队（6名助理工程师）日常管理，以及项目/所在业务工作落实和指标的达成'
      ]
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
          过往经历
        </h2>
        <p className="text-xl text-gray-600">
          丰富的工作经验与项目实践
        </p>
      </div>

      {/* 工作经历 */}
      <div>
        <h3 className="text-2xl font-bold text-gray-800 mb-8 flex items-center space-x-3">
          <Briefcase className="w-6 h-6 text-blue-600" />
          <span>工作经历</span>
        </h3>
        
        <div className="space-y-8">
          {workExperiences.map((exp, index) => (
            <div key={index} className="bg-white/80 backdrop-blur-sm p-8 rounded-3xl shadow-xl border border-white/20 hover:shadow-2xl transition-all duration-300">
              <div className="space-y-4">
                <div className="flex items-center space-x-2 text-sm text-blue-600 font-medium">
                  <Calendar className="w-4 h-4" />
                  <span>{exp.period}</span>
                </div>
                
                <div>
                  <h4 className="text-xl font-bold text-gray-800 mb-2 flex items-center space-x-2">
                    <Building className="w-5 h-5 text-purple-600" />
                    <span>{exp.company}</span>
                  </h4>
                  {exp.department && (
                    <p className="text-gray-600 mb-1">{exp.department}</p>
                  )}
                  <p className="text-lg font-semibold text-gray-700 mb-2">{exp.position}</p>
                  <div className="flex items-center space-x-2 text-sm text-gray-500 mb-3">
                    <MapPin className="w-4 h-4" />
                    <span>{exp.location}</span>
                  </div>
                  <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-3 rounded-2xl mb-4">
                    <p className="text-sm font-medium text-gray-700">{exp.type}</p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  {exp.achievements.map((achievement, achievementIndex) => (
                    <div key={achievementIndex} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-600 leading-relaxed">{achievement}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PastExperience;